<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface PasswordResetResponse extends Responsable
{
    //
}
