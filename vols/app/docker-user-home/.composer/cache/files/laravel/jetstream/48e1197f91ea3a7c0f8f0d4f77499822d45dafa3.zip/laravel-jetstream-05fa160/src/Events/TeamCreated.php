<?php

namespace Laravel\Jetstream\Events;

class TeamCreated extends TeamEvent
{
    //
}
